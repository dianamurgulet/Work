package predictive;

import java.util.HashSet;
import java.util.Set;

public class Sigs2WordsList {
	 
	public static void main(String[] args)
	{ 
		
		Set<String> similar= new HashSet<String>();

		Dictionary imp = new DictionaryListImpl();
		for(int i=0;i<args.length;i++)
		{
			System.out.println(imp.signatureToWords(args[i]));
		}
		
		
	}
	// 115 words: 2983
}
