package predictive;



public class Words2SigProto{
	
	public static void main(String[] args)
	{ 
//		for(int i=0;i<args.length;i++)
//		{
//			System.out.println(PredictivePrototype.wordToSignature(args[i]));//returns the signature of each of the words introduced
//		}
//		
		for(int i=0;i<args.length;i++)
		{
			System.out.println(PredictivePrototype.wordToSignature(args[i]));//returns the signature of each of the words introduced
		}
		
	}
}
